<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::auth();

Route::get('/home', 'HomeController@index');
Route::get('/', function () {
    return view('welcome');
});
Route::get('/about', function () {
    return view('about');
});
Route::get('/my_subjects', function () {
    return view('my_subjects');
});
Route::get('/my_social_media_accounts', function () {
    return view('my_social_media_accounts');
});
Route::get('/educational_background', function () {
    return view('educational_background');
});
Route::get('/about_php2', function () {
    return view('about_php2');
});