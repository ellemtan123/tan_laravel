@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">Educational Background</div>

                <div class="panel-body">
                        <table width="100%">
                        
                        <tr>
                           <th>PRIMARY:</th>
                           <td>Mambaling Elementary School</td>
                           <td>SY: 2001 - 2007</td>
                           
                       </tr>
                       <tr>
                           <th>Secondary:</th>
                           <td>Don Vicente Rama Memorial National Highschool</td>
                           <td>SY: 2007 - 2011</td>
                           
                       </tr>
                       <tr>
                           <th>Tertiary:</th>
                           <td>University of Cebu - Main Campus</td>
                           <td>SY: 2013 - Present</td>
                           
                       </tr>
                       
                    
                            </tr>

                          

                        </table>


                  </div>
            </div>
        </div>
    </div>
</div>
@endsection

