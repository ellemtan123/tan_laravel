@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">About PHP2</div>

                <div class="panel-body">
                   <p>
                       A PHP2 file is a web file that may contain PHP 2 source code. The PHP code within the page is parsed by a PHP engine on the web server that dynamically generates HTML sent to the user's web browser. The file may be used in combination with the MySQL database. PHP2 pages can be processed by Apache, Windows Server, or Mac OS X Server with the PHP engine installed. They can be edited with a text editor or web development program.The PHP2 file uncommon as PHP pages generally use the .PHP file extension. Our goal is to help you understand what a file with a *.php2 suffix is and how to open it. The PHP 2 Web Page file type, file format description, and Mac, Windows, and Linux programs listed on this page have been individually researched and verified by the FileInfo team. We strive for 100% accuracy and only publish information about file formats that we have tested and validated.

                   </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
